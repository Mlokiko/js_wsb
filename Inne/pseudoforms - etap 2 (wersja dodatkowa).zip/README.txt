npm install express

npm install better-sqlite3



-------------------------- testy API --------------------------

PRZYKŁADOWE ANKIETY


id: 0250e4c2-1192-4a22-846f-97772d52c6e3
curl -X PUT http://localhost:3000/surveys/0250e4c2-1192-4a22-846f-97772d52c6e3/submit -H "Content-Type: application/json" -d "{\"answers\":[\"A\",\"Tak\"]}"


id: 6reyeecdc0-c133-4def-9e00-ad8a2c128f71
curl -X PUT http://localhost:3000/surveys/6d4ecdc0-c133-4def-9e00-ad8a2c128f71/submit -H "Content-Type: application/json" -d "{\"answers\":[\"2-4h\",\"YouTube\"]}"


---------------------------------------------------------------
WIELE ODPOWIEDZI (multiple: true)
id: 1ad696b8-678c-43de-9f7b-eba59647efcf

curl -X POST http://localhost:3000/surveys -H "Content-Type: application/json" -d "{\"title\":\"Technologie, z których korzystasz\",\"author\":\"Michał Wiśniewski\",\"questions\":[{\"text\":\"Z jakich technologii frontendowych korzystasz na co dzień?\",\"options\":[\"HTML\",\"CSS\",\"JavaScript\",\"React\",\"Vue\",\"Angular\"],\"multiple\":true},{\"text\":\"Czy korzystasz z systemu kontroli wersji (np. Git)?\",\"options\":[\"Tak\",\"Nie\"]}]}"

curl -X PUT http://localhost:3000/surveys/1ad696b8-678c-43de-9f7b-eba59647efcf/submit -H "Content-Type: application/json" -d "{\"answers\":[[\"HTML\",\"CSS\",\"JavaScript\"],\"Tak\"]}"
curl -X PUT http://localhost:3000/surveys/1ad696b8-678c-43de-9f7b-eba59647efcf/submit -H "Content-Type: application/json" -d "{\"answers\":[[\"HTML\",\"JavaScript\"],\"Nie\"]}"
---------------------------------------------------------------


- Pobieranie listy ankiet (GET /surveys) zwraca tablicę z ankietami
curl http://localhost:3000/surveys


- Pobieranie konkretnej ankiety (GET /surveys/:id)
curl http://localhost:3000/surveys/<ID>


- Tworzenie ankiety (POST /surveys) zwraca utworzoną ankiete z id (UUID)
curl -X POST http://localhost:3000/surveys -H "Content-Type: application/json" -d "{\"title\":\"Ankieta o programowaniu\",\"author\":\"Jan Kowalski\",\"questions\":[{\"text\":\"Jaki język lubisz najbardziej?\",\"options\":[\"JavaScript\",\"Python\",\"C++\"]},{\"text\":\"Czy lubisz backend?\",\"options\":[\"Tak\",\"Nie\"]}]}"

curl -X POST http://localhost:3000/surveys -H "Content-Type: application/json" -d "{\"title\":\"Twoje nawyki cyfrowe\",\"author\":\"Anna Nowak\",\"questions\":[{\"text\":\"Ile godzin dziennie spędzasz przed ekranem?\",\"options\":[\"^<2h\",\"2-4h\",\"5-8h\",\"więcej niż 8h\"]},{\"text\":\"Z jakiej platformy korzystasz najczęściej?\",\"options\":[\"YouTube\",\"Instagram\",\"TikTok\",\"Facebook\"]}]}"


- Wysyłanie odpowiedzi na pytania (PUT) zwraca message
curl -X PUT http://localhost:3000/surveys/<ID>/submit -H "Content-Type: application/json" -d "{\"answers\":[\"A\",\"B\"]}"


- Usuwanie ankiety (DELETE) zwraca message
curl -X DELETE http://localhost:3000/surveys/<ID>



