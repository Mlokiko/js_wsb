const Survey = require('../models/surveyModel');
const surveyService = require('../services/surveyService');

// Synchronizacja JSON z bazą danych przy starcie
surveyService.sync();

// GET /surveys 
exports.getAllSurveys = (req, res) => {
  try {
    const surveys = surveyService.getAll();//zamiast Survey.getAllsurveys()
    res.json(surveys);
  } catch (err) {
    res.status(500).json({ error: 'Nie udało się pobrać ankiet' });
  }
};

// GET /surveys/:id 
exports.getSurveyById = (req, res) => {
  const { id } = req.params;
  const survey = surveyService.getById(id);//zamiast Survey.getSurveyById(id)

  if (!survey) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  res.json(survey);
};

// POST /surveys 
exports.createSurvey = (req, res) => {
  const { title, author, questions } = req.body;

  if (!title || !author || !Array.isArray(questions)) {
    return res.status(400).json({ error: 'Brak wymaganych pól: title, author, questions' });
  }

  try {
    const newSurvey = surveyService.create({ title, author, questions });//zamiast Survey.createSurvey({ title, author, questions })
    res.status(201).json(newSurvey);
  } catch (err) {
    res.status(500).json({ error: 'Błąd przy tworzeniu ankiety' });
  }
};

// PUT /surveys/:id/submit 
exports.submitSurvey = (req, res) => {
  const { id } = req.params;
  const { answers } = req.body;

  const survey = surveyService.getById(id);//zamiast Survey.getSurveyById(id)

  if (!survey) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  if (!Array.isArray(answers) || answers.length !== survey.questions.length) {
    return res.status(400).json({ error: 'Nieprawidłowa liczba odpowiedzi' });
  }

  const success = surveyService.submit(id, answers);//zamiast Survey.submitSurvey(id, answers)

  if (success) {
    res.status(200).json({ message: 'Odpowiedzi zapisane' });
  } else {
    res.status(500).json({ error: 'Nie udało się zapisać odpowiedzi' });
  }
};

// DELETE /surveys/:id 
exports.deleteSurvey = (req, res) => {
  const { id } = req.params;
  const success = surveyService.deleteSurvey(id);//zamiast Survey.deleteSurvey(id)

  if (!success) {
    return res.status(404).json({ error: 'Ankieta nie znaleziona' });
  }

  res.status(200).json({ message: 'Ankieta została usunięta' });
};