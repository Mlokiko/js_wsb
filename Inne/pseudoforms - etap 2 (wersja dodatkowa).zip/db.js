const Database = require('better-sqlite3');
const db = new Database('data.db');

db.prepare(`
  CREATE TABLE IF NOT EXISTS surveys (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    questions TEXT NOT NULL,
    responses TEXT,
    createdAt TEXT NOT NULL
  )
`).run();

module.exports = db;
