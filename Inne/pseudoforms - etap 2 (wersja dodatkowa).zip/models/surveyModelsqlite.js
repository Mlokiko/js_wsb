const db = require('../db');
const fs = require('fs');
const path = require('path');


function syncJsonToDb() {
  const jsonPath = path.join(__dirname, '../data/surveys.json');
  const surveys = JSON.parse(fs.readFileSync(jsonPath));

  const stmt = db.prepare(`INSERT OR IGNORE INTO surveys (id, title, author, questions, responses, createdAt) VALUES (?, ?, ?, ?, ?, ?)`);

  surveys.forEach(s => {
    stmt.run(
      s.id,
      s.title,
      s.author,
      JSON.stringify(s.questions),
      JSON.stringify(s.responses),
      s.createdAt
    );
  });
}

function getAll() {
    try {
      return db.prepare('SELECT * FROM surveys').all().map(row => ({
        ...row,
        questions: JSON.parse(row.questions),
        responses: JSON.parse(row.responses)
      }));
    } catch (err) {
      console.error("Błąd w getAll():", err);
      throw err;
    }
  }
  

function getById(id) {
  const row = db.prepare('SELECT * FROM surveys WHERE id = ?').get(id);
  if (!row) return null;
  return {
    ...row,
    questions: JSON.parse(row.questions),
    responses: JSON.parse(row.responses)
  };
}

function create({ id, title, author, questions, createdAt }) {
  db.prepare(`INSERT INTO surveys (id, title, author, questions, responses, createdAt) VALUES (?, ?, ?, ?, ?, ?)`)
    .run(id, title, author, JSON.stringify(questions), JSON.stringify([]), createdAt);

  return getById(id);
}

function submit(id, answers) {
  const survey = getById(id);
  if (!survey) return null;

  survey.responses.push(answers);

  db.prepare(`UPDATE surveys SET responses = ? WHERE id = ?`)
    .run(JSON.stringify(survey.responses), id);

  return true;
}

function remove(id) {
  const info = db.prepare('DELETE FROM surveys WHERE id = ?').run(id);
  return info.changes > 0;
}

module.exports = {
  syncJsonToDb,
  getAll,
  getById,
  create,
  submit,
  remove
};
