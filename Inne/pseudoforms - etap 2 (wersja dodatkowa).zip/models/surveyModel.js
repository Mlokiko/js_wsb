const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const dataPath = path.join(__dirname, '../data/surveys.json');

function getAllSurveys() {
  const raw = fs.readFileSync(dataPath);
  return JSON.parse(raw);
}

function saveSurveys(surveys) {
  fs.writeFileSync(dataPath, JSON.stringify(surveys, null, 2));
}

function getSurveyById(id) {
  const surveys = getAllSurveys();
  return surveys.find(s => s.id === id);
}

function createSurvey({ title, author, questions }) {
  const surveys = getAllSurveys();

  const newSurvey = {
    id: uuidv4(),
    title,
    author,
    questions,
    createdAt: new Date().toISOString(),
    responses: []
  };

  surveys.push(newSurvey);
  saveSurveys(surveys);

  return newSurvey;
}

function submitSurvey(id, answers) {
  const surveys = getAllSurveys();
  const survey = surveys.find(s => s.id === id);

  if (!survey) return null;

  survey.responses.push(answers);
  saveSurveys(surveys);

  return true;
}

function deleteSurvey(id) {
  const surveys = getAllSurveys();
  const index = surveys.findIndex(s => s.id === id);
  if (index === -1) return false;

  surveys.splice(index, 1);
  saveSurveys(surveys);
  return true;
}

module.exports = {
  getAllSurveys,
  getSurveyById,
  createSurvey,
  submitSurvey,
  deleteSurvey
};