// services/surveyService.js
const Survey = require('../models/surveyModelsqlite');

exports.getAll = () => Survey.getAll();
exports.getById = (id) => Survey.getById(id);
exports.create = (data) => {
  const id = require('uuid').v4();
  const createdAt = new Date().toISOString();
  return Survey.create({ ...data, id, createdAt });
};
exports.submit = (id, answers) => Survey.submit(id, answers);
exports.remove = (id) => Survey.remove(id);
exports.sync = () => Survey.syncJsonToDb();
