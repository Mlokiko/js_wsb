<template>
    <footer>
      &copy; 2025 FormHub. All rights reserved.
    </footer>
  </template>
  
  <style scoped>
  footer {
    text-align: center;
    padding: 1rem;
    font-size: 0.8rem;
    color: #888;
  }
  </style>
  